# simple-snake

simple snake game using pure javascript in the simple way
